package com.example.bankwidget

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        box.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Нажмите кнопку и включите доступ к уведомлениям для «Мой баланс».\n" +
                "2. Добавьте виджет на главный экран.\n\n" +
                "Приложение только читает уведомления Т-Банка. Оно не имеет доступа к счетам и не может проводить операции. " +
                "Данные появятся после первого уведомления от банка и хранятся только на телефоне."
        })
        box.addView(Button(this).apply {
            text = "Открыть настройки доступа"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        setContentView(box)
    }
}
