package com.example.bankwidget

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BankListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName.lowercase()
        if (!pkg.contains("tinkoff") && !pkg.contains("tbank") && !pkg.contains("tcsbank")) return
        val ex = sbn.notification.extras
        val text = listOfNotNull(ex.getCharSequence("android.title"), ex.getCharSequence("android.bigText") ?: ex.getCharSequence("android.text"))
            .joinToString(". ")
        val r = Parser.parse(text) ?: return
        Store.save(this, r.first, r.second)
        BalanceWidget.refresh(this)
    }
}
