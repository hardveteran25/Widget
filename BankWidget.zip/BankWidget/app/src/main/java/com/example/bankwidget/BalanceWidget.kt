package com.example.bankwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import java.text.NumberFormat
import java.util.Locale

class BalanceWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = refresh(c)

    companion object {
        private fun fmt(v: Double?) =
            if (v == null) "—" else NumberFormat.getNumberInstance(Locale("ru")).apply { maximumFractionDigits = 0 }.format(v) + " ₽"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, BalanceWidget::class.java))
            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setTextViewText(R.id.balance, fmt(Store.balance(c)))
            v.setTextViewText(R.id.spent, fmt(Store.spent(c)))
            m.updateAppWidget(ids, v)
        }
    }
}
