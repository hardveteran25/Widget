package com.example.bankwidget

object Parser {
    private val spendWords = Regex("(?i)(покупка|оплата|снятие|платеж|списание)")
    private val balanceRe = Regex("(?i)(?:доступно|остаток|баланс)[:\\s]+(-?[\\d\\s\\u00A0]+(?:[.,]\\d{1,2})?)\\s*(?:₽|р|руб)")
    private val amountRe = Regex("(\\d[\\d\\s\\u00A0]*(?:[.,]\\d{1,2})?)\\s*(?:₽|р\\.?|руб)")

    private fun num(s: String) = s.replace(Regex("[\\s\\u00A0]"), "").replace(',', '.').toDoubleOrNull()

    /** Возвращает пару (баланс, сумма траты) или null. */
    fun parse(text: String): Pair<Double?, Double>? {
        val bal = balanceRe.find(text)?.groupValues?.get(1)?.let(::num)
        var spent = 0.0
        if (spendWords.containsMatchIn(text)) {
            val cut = balanceRe.find(text)?.range?.first ?: text.length
            spent = amountRe.find(text.substring(0, cut))?.groupValues?.get(1)?.let(::num) ?: 0.0
        }
        return if (bal == null && spent == 0.0) null else bal to spent
    }
}
