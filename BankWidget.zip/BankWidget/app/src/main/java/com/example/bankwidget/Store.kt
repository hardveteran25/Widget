package com.example.bankwidget

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

object Store {
    private fun p(c: Context) = c.getSharedPreferences("bank", Context.MODE_PRIVATE)
    private fun month() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

    fun balance(c: Context): Double? = p(c).getString("balance", null)?.toDouble()
    fun spent(c: Context): Double = p(c).getString("spent_" + month(), "0")!!.toDouble()

    fun save(c: Context, balance: Double?, spent: Double) {
        val e = p(c).edit()
        if (balance != null) e.putString("balance", balance.toString())
        if (spent > 0) e.putString("spent_" + month(), (spent(c) + spent).toString())
        e.apply()
    }
}
